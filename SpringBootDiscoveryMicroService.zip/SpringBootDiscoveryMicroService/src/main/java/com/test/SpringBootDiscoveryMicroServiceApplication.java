package com.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class SpringBootDiscoveryMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDiscoveryMicroServiceApplication.class, args);
	}

}
